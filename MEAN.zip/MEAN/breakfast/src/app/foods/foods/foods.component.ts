import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiServiceService } from 'src/app/api-service/api-service.service';
import { ComunicateService } from 'src/app/api-service/comunicate.service';
import { MatDialogEx } from 'src/app/matDialogEx';
import jwt_decode from "jwt-decode";

@Component({
  selector: 'app-foods',
  templateUrl: './foods.component.html',
  styleUrls: ['./foods.component.css']
})
export class FoodsComponent implements OnInit, AfterViewInit, OnDestroy {
  urlId: any;
  productItemCount: number = 0;
  specificData: any;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'bottom';
  totalPriceOn: any;
  msgOn: any;
  actionBar: any;
  loginChk = localStorage.getItem("auth");
  constructor(
    private routes: ActivatedRoute,
    private apiService: ApiServiceService,
    private comunicate: ComunicateService,
    private _snackBar: MatSnackBar,
    private router: Router,
    private matDialog: MatDialogEx
  ) { }

  ngOnInit() {
    this.getDataFoodItem();
    this.comunicate.loginCheck.subscribe(() => {
      this.getDataFoodItem();
    });
  }
  ngAfterViewInit() {
    this.comunicate.logoutCheck.subscribe((res) => {
      this.getDataFoodItem();
    });
  }
  getDataFoodItem() {
    this.routes.params.subscribe(res => {
      this.urlId = res['id'];
      this.apiService.foods(res['id']).subscribe(res => { this.specificData = res; });
    });
  }
  addItemInc(data: any) {
    this.loginChk = localStorage.getItem("auth");
    if (!this.loginChk) {
      this.matDialog.matDialogFunc();
    }
    else {
      data.count++;
      this.productItemCountFunc(this.loginChk, data);
    }
  }
  addItemDec(data: any) {
    this.loginChk = localStorage.getItem("auth");
    if (!this.loginChk) {
      this.matDialog.matDialogFunc();
    }
    else {
      data.count--;
      this.productItemCountFunc(this.loginChk, data);
    }
  }
  productItemCountFunc(token: string, data: any) {
    data['productItemCount'] = data.count;
    const decode: any = jwt_decode(token);
    data['userId'] = decode?.userId;
    this.apiService.productItemCount(data).subscribe(res => {
      this.cartItemSum(decode?.userId);
    });
  }
  cartItemSum(userIdTkn: any) {
    this.apiService.cartItemCount(userIdTkn).subscribe((res: any) => {
      const totalItem = res?.totalItem;
      const totalPrice = res?.totalPrice;
      this.comunicate.comunicate.next(res);
      this.msgOn = totalItem ? ((totalItem > 1 ? totalItem + ' items' : totalItem + ' item') + ' = ' + totalPrice) : ('Cart Empty');
      this.openSnackBar(totalItem, this.msgOn);
    });
  }
  openSnackBar(totalItem: any, data: any) {
    let snackBar = this._snackBar.open(data, 'View Cart', {
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      duration: totalItem ? 0 : 1000
    });
    snackBar.onAction().subscribe(() => {
      this.router.navigate(['/foods/cart/details']);
    });
    snackBar.afterDismissed();
    this.actionBar = snackBar;
  }
  ngOnDestroy() {
    if (this.msgOn) {
      this.actionBar.dismiss();
    }
  }
}
