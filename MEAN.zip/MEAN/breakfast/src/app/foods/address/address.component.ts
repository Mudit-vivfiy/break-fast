import { TitleCasePipe } from '@angular/common';
import { AfterViewChecked, AfterViewInit, ChangeDetectorRef, Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiServiceService } from 'src/app/api-service/api-service.service';
import { Inject } from '@angular/core';
import jwtDecode from 'jwt-decode';
import { MatDialogEx } from 'src/app/matDialogEx';
import { ComunicateService } from 'src/app/api-service/comunicate.service';

@Component({
  selector: 'app-address',
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.css'],
  providers: [TitleCasePipe]
})
export class AddressComponent implements AfterViewInit, AfterViewChecked {
  form: any;
  cities: any;
  constructor(
    private apiService: ApiServiceService,
    private fb: FormBuilder,
    private titleCase: TitleCasePipe,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public changeDetect: ChangeDetectorRef,
    private matDialogRef: MatDialogRef<AddressComponent>,
    private matDialogEx: MatDialogEx,
    private communicate: ComunicateService
  ) { }
  ngOnInit() {
    this.form = this.fb.group({
      name: ['', Validators.required],
      pincode: ['', Validators.required],
      city: ['', Validators.required],
      district: ['', Validators.required],
      state: ['', Validators.required],
      address: ['', Validators.required],
      addressCategory: ['', Validators.required]
    });
  }
  ngAfterViewInit() {
    const token: any = localStorage.getItem("auth");
    const decode: any = jwtDecode(token);
    this.form.patchValue({
      name: decode?.name,
      pincode: this.data?.address?.pincode,
      city: this.data?.address?.city,
      district: this.data?.address?.district,
      state: this.data?.address?.state,
      address: this.data?.address?.address,
      addressCategory: this.data?.address?.addressCategory
    });
    if (this.data?.address)
      this.getAddByPinCodeFunc(this.data?.address?.pincode);
  }
  ngAfterViewChecked() {
    this.changeDetect.detectChanges();
  }
  onClick(event: any) {
    if ((event.target.value).length >= 6 && (event.target.value).length <= 10) {
      this.getAddByPinCodeFunc(event.target.value);
    }
  }
  getAddByPinCodeFunc(value: any) {
    this.apiService.AddByIn(value).subscribe((res: any) => {
      this.form.patchValue({ pincode: this.titleCase.transform(res?.data[0]), district: this.titleCase.transform(res?.data[1]), state: this.titleCase.transform(res?.data[2]) });
      this.cities = res?.data[3];
    });
  }
  get f() {
    return this.form.controls;
  }
  submit() {
    const token: any = localStorage.getItem("auth");
    const decode: any = jwtDecode(token);
    if (new Date(decode.exp * 1000) > new Date()) {
      this.form.value['userId'] = this.data?.userId;
      this.form.value['city'] = this.titleCase.transform(this.form.value?.city);
      this.apiService.customerAddressCreateData(this.form?.value).subscribe((res: any) => {
        console.log(res?.message);
        this.communicate.comunicate.next(res);
      });
    }
    else {
      this.matDialogEx.matDialogFunc();
    }
  }
  cancel() {
    this.matDialogRef.close();
  }
}
