import { DialogRef } from '@angular/cdk/dialog';
import { AfterViewInit, Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { forkJoin } from 'rxjs';
import { ApiServiceService } from 'src/app/api-service/api-service.service';
import { ComunicateService } from 'src/app/api-service/comunicate.service';
import { MatDialogEx } from 'src/app/matDialogEx';
import jwt_decode from "jwt-decode";

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit, AfterViewInit {
  cartDetails: any;
  _customerAddressData: any;
  _customerData: any;
  form: any;
  invoiceDownload: any;
  totalCountN: any;
  loginChk: any = localStorage.getItem("auth");
  constructor(
    private apiService: ApiServiceService,
    private comunicate: ComunicateService,
    private matDialog: MatDialog,
    private fb: FormBuilder,
    private matDialogEx: MatDialogEx
  ) { }

  ngOnInit() {
    this.form = this.fb.group({
      timeslot: ['', Validators.required]
    });
  }
  ngAfterViewInit() {
    this.queryPramasData();
    this.customerData(localStorage.getItem("auth"));
    this.comunicate.loginCheck.subscribe(res => {
      this.queryPramasData();
    });
    this.comunicate.logoutCheck.subscribe(res => {
      this.queryPramasData();
    });
  }
  get f() {
    return this.form.controls;
  }
  queryPramasData() {
    if (localStorage.getItem("auth")) {
      this.loginChk = localStorage.getItem("auth");
      const decode: any = jwt_decode(this.loginChk);
      this.apiService.cartItemCount(decode?.userId).subscribe((res: any) => {
        this.cartDetails = res;
        this.totalCountN = (res?.totalItem) ? res?.totalItem : 0;
      });
    }
    else {
      this.cartDetails = '';
      this.totalCountN = 0;
    }
  }
  addItemInc(data: any) {
    this.loginChk = localStorage.getItem("auth");
    if (!this.loginChk) {
      this.matDialogEx.matDialogFunc();
    }
    else {
      data.count++;
      this.productItemCountFunc(this.loginChk, data);
    }
  }
  addItemDec(data: any) {
    this.loginChk = localStorage.getItem("auth");
    if (!this.loginChk) {
      this.matDialogEx.matDialogFunc();
    }
    else {
      data.count--;
      this.productItemCountFunc(this.loginChk, data);
    }
  }
  productItemCountFunc(token: string, data: any) {
    data['productItemCount'] = data.count;
    const decode: any = jwt_decode(token);
    data['userId'] = decode?.userId;
    this.apiService.productItemCount(data).subscribe(res => {
      this.comunicate.comunicate.next(data);
      this.queryPramasData();
    });
  }
  openDialog(cartItemDetail: any) {
    const matDialog = this.matDialog.open(DeleteDialogBox, {
      data: cartItemDetail
    });
    matDialog.afterClosed().subscribe((result) => {
      this.apiService.deleteCartItem(result).subscribe(res => {
        this.queryPramasData();
        this.comunicate.comunicate.next(cartItemDetail);
      });
    });
  }
  customerData(id: any) {
    if (id) {
      const decode: any = jwt_decode(id);
      forkJoin<any>({
        customerData: this.apiService.customerData(decode?.userId),
        customerAddressData: this.apiService.customerAddressData(decode?.userId)
      }).subscribe(({ customerData, customerAddressData }: any) => {
        this._customerAddressData = customerAddressData?.data;
        this._customerData = customerData?.data;
      });
    }
    else {
      console.log(id)
    }
  }
  payNow(cartDetail: any, customerOrder: any, customer: any) {
    const token: any = localStorage.getItem("auth");
    const decode: any = jwt_decode(token);
    if (new Date(decode.exp * 1000) > new Date()) {
      const arr = ['id', 'userId', 'createdAt', 'updatedAt', 'release_date'];
      for (let val of arr) { delete customerOrder[val]; }
      customerOrder['userId'] = customer['userId'];
      customerOrder['customerName'] = customer['name'];
      customerOrder['customerMobile'] = customer['mobile'];
      customerOrder['customerCartDetails'] = cartDetail;
      customerOrder['timeSlot'] = this.form?.controls?.timeslot?.value;
      this.apiService.customerOrder(customerOrder).subscribe((res: any) => {
        this.invoiceDownload = res?.data?.orderId;
      });
    }
    else {
      this.matDialogEx.matDialogFunc();
    }
  }
  addressInsert(userId: any) {
    const addInsert = this.matDialogEx.addressInsert(userId, this._customerAddressData);
    addInsert.afterClosed().subscribe((res) => {
      this.customerData(this.loginChk);
    });
  }
}

@Component({
  selector: 'delete-dialogbox',
  templateUrl: './delete-dialog.html'
})
export class DeleteDialogBox {
  constructor(private dialogRef: DialogRef<any>, @Inject(MAT_DIALOG_DATA) public data: any) { }
  onNoClick() {
    this.dialogRef.close();
  }
}