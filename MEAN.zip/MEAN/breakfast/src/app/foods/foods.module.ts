import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FoodsRoutingModule } from './foods-routing.module';
import { FoodsComponent } from './foods/foods.component';
import { MaterialExampleModule } from 'src/material.module';
import { CartComponent, DeleteDialogBox } from './cart/cart.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddressComponent } from './address/address.component';


@NgModule({
  declarations: [
    FoodsComponent,
    CartComponent,
    DeleteDialogBox,
    AddressComponent
  ],
  imports: [
    CommonModule,
    FoodsRoutingModule,
    MaterialExampleModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class FoodsModule { }
