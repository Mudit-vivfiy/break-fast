import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../guard/auth.guard';
import { CartComponent } from './cart/cart.component';
import { FoodsComponent } from './foods/foods.component';

const routes: Routes = [{
  path: ':id', component: FoodsComponent,
}, {
  path: 'cart/:id', canActivate: [AuthGuard], component: CartComponent,
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FoodsRoutingModule { }
