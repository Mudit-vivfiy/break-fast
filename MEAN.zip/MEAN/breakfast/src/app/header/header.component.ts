import { Component } from '@angular/core';
import { Router } from '@angular/router';
import jwtDecode from 'jwt-decode';
import { ApiServiceService } from '../api-service/api-service.service';
import { ComunicateService } from '../api-service/comunicate.service';
import { MatDialogEx } from '../matDialogEx';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {
  foodCategories: any[] = ['drinks', 'foods', 'fruits', 'combopacks'];
  totalItemCount: any;
  cartDetails: any;
  menuChk: any = localStorage.getItem('auth') ? localStorage.getItem('auth') : '';
  profileName: any;
  addressShow: any;
  custAdd: any;
  constructor(private apiservice: ApiServiceService, private comunicate: ComunicateService, private router: Router, private matDialogEx: MatDialogEx) { }
  ngOnInit() {
    this.cartItemCountFunc();
    this.cartItemCheck();
  }
  ngAfterViewInit() {
    this.comunicate.loginCheck.subscribe((res) => {
      this.menuChk = localStorage.getItem('auth');
      this.cartItemCountFunc();
    });
    this.comunicate.logoutCheck.subscribe((res) => {
      this.menuChk = localStorage.getItem('auth');
      this.cartItemCountFunc();
    });
    this.comunicate.comunicate.subscribe((res) => {
      this.getAddress();
    });
  }
  cartItemCountFunc() {
    if (this.menuChk) {
      this.menuChk = localStorage.getItem("auth");
      const decode: any = jwtDecode(this.menuChk);
      if (new Date(decode.exp * 1000) > new Date()) {
        this.profileName = decode?.name ? decode?.name : decode?.mobile;
        this.apiservice.cartItemCount(decode?.userId).subscribe((res: any) => {
          this.totalItemCount = (res.totalItem) ? res.totalItem : 0;
          this.cartDetails = res;
          this.getAddress();
        });
      }
      else {
        this.addressShow = '';
        this.custAdd = '';
        this.logout();
      }
    }
    else {
      this.addressShow = '';
      this.custAdd = '';
      this.totalItemCount = 0;
      this.cartDetails = '';
    }
  }
  cartItemCheck() {
    this.comunicate.comunicate.subscribe(res => {
      this.cartItemCountFunc();
      this.menuChk = localStorage.getItem('auth');
    });
  }
  cartDetailsEvent() {
    this.router.navigate(['/foods/cart/details']);
  }
  foodscategory(foodCate: string) {
    this.cartItemCountFunc();
    this.router.navigate([`./foods/${foodCate}`]);
  }
  userLogin() {
    this.matDialogEx.matDialogFunc();
  }
  logout() {
    localStorage.removeItem("auth");
    this.menuChk = localStorage.getItem('auth');
    this.comunicate.logoutCheck.next(this.menuChk);
  }
  addressInsert() {
    const token: any = localStorage.getItem("auth");
    if (token) {
      const decode: any = jwtDecode(token);
      if (new Date(decode.exp * 1000) > new Date()) {
        this.apiservice.customerAddressData(decode?.userId).subscribe((res: any) => {
          this.matDialogEx.addressInsert(decode?.userId, res?.data);
          this.getAddress()
        });
      }
      else {
        this.addressShow = '';
        this.custAdd = '';
        this.userLogin();
      }
    }
    else {
      this.addressShow = '';
      this.custAdd = '';
      this.userLogin();
    }
  }

  getAddress() {
    const token: any = localStorage.getItem("auth");
    if (token) {
      const decode: any = jwtDecode(token);
      if (new Date(decode.exp * 1000) > new Date()) {
        this.apiservice.customerAddressData(decode?.userId).subscribe((res: any) => {
          const district = res?.data?.district;
          this.custAdd = res?.data;
          this.addressShow = district + '\xa0'.repeat((15 - district?.length));
        });
      }
    }
  }
}
