import { Injectable } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { AddressComponent } from "./foods/address/address.component";
import { UserComponent } from "./user/user.component";
@Injectable({
    providedIn: 'root'
})
export class MatDialogEx {
    constructor(private matDialogPop: MatDialog) { }
    matDialogFunc() {
       return this.matDialogPop.open(UserComponent, {
            width: '304px',
            autoFocus: false
        });
    }
    addressInsert(userId: any, addressData: any) {
     return  this.matDialogPop.open(AddressComponent, {
            width: '612px',
            height: '430px',
            autoFocus: false,
            data: { userId: userId, address: addressData }
        });
    }
}
