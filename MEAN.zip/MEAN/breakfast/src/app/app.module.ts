import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { MaterialExampleModule } from 'src/material.module';
import { ApiServiceService } from './api-service/api-service.service';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UserComponent } from './user/user.component';
import { NgOtpInputModule } from 'ng-otp-input';
import { HttpHeadersInterceptor } from './http-intercepter/http-headers.interceptor';
import { MatDialogEx } from './matDialogEx';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    UserComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MaterialExampleModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    FormsModule,
    NgOtpInputModule
  ],
  exports: [MaterialExampleModule, ReactiveFormsModule, FormsModule],
  providers: [
    ApiServiceService,
    { provide: HTTP_INTERCEPTORS, useClass: HttpHeadersInterceptor, multi: true },
    { provide: MatDialogEx, useClass: MatDialogEx }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
