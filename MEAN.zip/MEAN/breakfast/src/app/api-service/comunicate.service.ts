import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ComunicateService {
  comunicate = new Subject();
  sendDataInCart = new Subject();
  loginCheck = new Subject();
  logoutCheck = new Subject();
  constructor() { }
  auth(){
    return localStorage.getItem('auth');
  }
}
