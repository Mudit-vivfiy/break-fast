import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ApiServiceService {

  constructor(private http: HttpClient) { }

  foods(categoryId: any) {
    return this.http.get(`http://localhost:3000/foods/${categoryId}`);
  }

  productItemCount(productItemData: any) {
    return this.http.post(`http://localhost:3000/productCount`, productItemData)
  }

  cartItemCount(userId: any) {
    return this.http.get(`http://localhost:3000/cartItemCount/${userId}`);
  }

  deleteCartItem(deleteCartId: any) {
    return this.http.delete(`http://localhost:3000/deleteCartItem/${deleteCartId}`);
  }
  customerData(userId: any) {
    return this.http.get(`http://localhost:3000/customers/${userId}`);
  }
  customerAddressData(userId: any) {
    return this.http.get(`http://localhost:3000/cutomerAddresses/${userId}`);
  }
  customerAddressCreateData(data: any) {
    return this.http.post(`http://localhost:3000/cutomerAddressesCreate`, data);
  }
  customerOrder(order: any) {
    return this.http.post(`http://localhost:3000/customerOrder`, order);
  }
  invoiceDownload(orderId: any) {
    return this.http.get(`http://localhost:3000/invoiceDownload/${orderId}`);
  }
  sendMsgOtp(data: any) {
    return this.http.post(`http://localhost:3000/sendotp`, data);
  }
  verifyOtp(data: any) {
    return this.http.get(`http://localhost:3000/verifyotp/${data}`);
  }
  AddByIn(pincode: any){
    return this.http.get(`http://localhost:3000/addByPin/${pincode}`);
  }
}
