import { Component, ElementRef, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ApiServiceService } from '../api-service/api-service.service';
import { ComunicateService } from '../api-service/comunicate.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css'],
})
export class UserComponent implements OnInit {
  form: any;
  inputBolean: boolean = true;
  mobileNum: any;
  constructor(
    private _formBuilder: FormBuilder,
    private apiService: ApiServiceService,
    private el: ElementRef,
    private router: Router,
    private matDialogRef: MatDialogRef<UserComponent>,
    private communicate: ComunicateService
  ) { }
  ngOnInit(): void {
    this.form = this._formBuilder.group({
      mobile: ['', [Validators.required, Validators.pattern("^[6-9][0-9]{9}$")]]
    });
  }
  get f() {
    return this.form.controls;
  }
  onOtpVerify(event: any) {
    if (event.length === 6) {
      this.apiService.verifyOtp(event).subscribe((res: any) => {
        const respo = res?.data;
        if (respo) {
          this.tempFunc(respo, '#000000');
          this.communicate.loginCheck.next(respo);
          this.router.navigate([this.router?.routerState?.snapshot?.url]);
          setTimeout(() => {
            this.matDialogRef.close();
          }, 1000);
        }
        else {
          this.tempFunc(respo, '#ef4444');
        }
      });
    }
  }
  tempFunc(response: any, color: string) {
    localStorage.setItem('auth', response);
    this.el.nativeElement.style.setProperty('--black', color);
  }

  resendOTP() {

  }

  edit() {
    this.inputBolean = this.inputBolean ? false : true;
  }

  login() {
    this.inputBolean = this.inputBolean ? false : true;
    this.mobileNum = this.form.controls.mobile.value;
    this.apiService.sendMsgOtp(this.form.value).subscribe((res: any) => {
      console.log(res);
    });
  }
}
