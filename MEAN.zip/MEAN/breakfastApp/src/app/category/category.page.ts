import { Component } from '@angular/core';
import { ApiServiceService } from '../api-service/api-service.service';

@Component({
  selector: 'app-category',
  templateUrl: 'category.page.html',
  styleUrls: ['category.page.scss']
})
export class CategoryPage {
  specificData: any;
  foodCategories: any[] = ['drinks', 'foods', 'fruits', 'combopacks'];
  activeCategory: any;
  urlImage: any;
  constructor(private apiservice: ApiServiceService) {}

  ngOnInit(){
    this.apiservice.prodImage("coffee").subscribe((res: any)=>{
      this.urlImage = res;
    })
  }

  getFoodccategory(event: any){
    this.activeCategory = event?.detail?.value;
    this.apiservice.foods(this.activeCategory).subscribe(res=>{
      this.specificData = res;
    });
  }
}
