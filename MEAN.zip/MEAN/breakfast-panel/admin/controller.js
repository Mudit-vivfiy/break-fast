const schema = require('../database/schema');
const { sequelize, Sequelize, DataTypes } = require('../database/db');
const generateInvoice = require('../utility/invoice_pdf');
const otpMSG = require('../utility/send_sms');
const jwt = require('jsonwebtoken');
const addByPinCode = require('../utility/csv');
const path = require("path");
this.foods = async (req, res) => {
    const { id } = req.params;
    const token = req?.headers?.authentication;
    let foods = await schema.Food.findAll({ where: { category: id } });
    if (token) {
        const verifyResTkn = jwt.verify(token, process.env.SECRET_KEY);
        if (verifyResTkn)
            for (let i = 0; i < foods.length; i++) {
                let foodABC = await schema.ProductItemCount.findOne({ where: { foodId: foods[i]['dataValues']['id'], userId: verifyResTkn?.userId } });
                foods[i]['dataValues']['count'] = foodABC?.dataValues?.count ? foodABC?.dataValues?.count : null;
                foods[i]['dataValues']['foodId'] = foods[i]['dataValues']['id'];
                delete foods[i]['dataValues']['id'];
            }
    }
    try {
        res.json(foods);
    } catch (error) {
        res.json(error);
    }
}
this.productItemCount = async (req, res) => {
    const body = req.body;
    const count = body?.productItemCount;
    const userIds = body?.userId;
    const productItemCount = schema.ProductItemCount;
    const FoodID = { where: { foodId: body?.foodId, userId: userIds } };
    const existsDataFind = await productItemCount.findOne(FoodID);
    if (existsDataFind) {
        if (count > 0) {
            const productItemCountA = await productItemCount.update({ count: count, release_date: new Date() }, FoodID);
            res.json({ data1: productItemCountA[0] });
        }
        else {
            const productItemCountA = await productItemCount.destroy(FoodID);
            res.json({ data2: productItemCountA });
        }
    }
    else {
        const productItemCountA = await productItemCount.create({ count: count, price: body?.price, priceoff: body?.priceoff, foodId: body?.foodId, release_date: new Date(), userId: body?.userId, name: body?.name, foodimage: body?.foodimage, description: body?.description });
        res.json({ data3: productItemCountA.dataValues });
    }
}

this.cartItemCount = async (req, res) => {
    const tknUserId = req?.params?.tknUserId;
    const itemCount = await schema.ProductItemCount.findAll({
        where: { userId: tknUserId },
        attributes: [
            'id', 'count', 'userId', 'foodId', 'name', 'foodimage', 'description', 'price', 'priceoff',
            [sequelize.literal('COALESCE(count, 0) * COALESCE(price, 0)'), 'total_price'],
            [sequelize.literal('COALESCE(count, 0) * COALESCE(priceoff, 0)'), 'total_priceoff'],
            [sequelize.literal('COALESCE(count, 0)'), 'total_item']
        ]
    });
    // const itemCount = await schema.ProductItemCount.findAll({
    //     where: { userId: tknUserId },
    //     attributes: [
    //         'id', 'count', 'userId', 'foodId', 'name', 'foodimage', 'description', 'price', 'priceoff',
    //         [sequelize.fn('sum', sequelize.where(sequelize.col('count'), '*', sequelize.col('price'))), 'total_price'],
    //         [sequelize.fn('sum', sequelize.where(sequelize.col('count'), '*', sequelize.col('priceoff'))), 'total_priceoff'],
    //         [sequelize.fn('sum', sequelize.col('count')), 'total_item']
    //     ]
    // });
    const totalCountPrice = itemCount.reduce((v, i) => { return v + (+i.dataValues.total_price); }, 0);
    const totalCountPriceOff = itemCount.reduce((v, i) => { return v + (+i.dataValues.total_priceoff); }, 0);
    const totalItem = itemCount.reduce((v, i) => { return v + (+i.dataValues.total_item); }, 0);
    res.json({ itemCount: itemCount, totalPriceOff: totalCountPriceOff, totalPrice: totalCountPrice, totalItem: totalItem });
}

this.deleteCartItem = async (req, res) => {
    const DeleteId = req.params.id;
    const deleteItem = await schema.ProductItemCount.destroy({ where: { id: DeleteId } });
    res.json({ data: deleteItem });
}

this.Customers = async (req, res) => {
    const userId = req.params.userId;
    const customerData = await schema.Customers.findOne({ where: { userId: userId } });
    res.json({ data: customerData });
}
this.CustomerAddressesCreate = async (req, res) => {
    const body = req?.body;
    const where = { where: { userId: body?.userId, addressCategory: body?.addressCategory } };
    const addData = { addressCategory: body?.addressCategory, pincode: body?.pincode, city: body?.city, district: body?.district, address: body?.address, state: body?.state, action: 1 };
    const addAction = await schema.CustomerAddresses.findOne({ where: { userId: body?.userId, action: 1 } });
    const CustomerAddressData = await schema.CustomerAddresses.findOne(where);
    if (!CustomerAddressData) {
        addActionFunc(addAction?.id, body?.userId, body?.name);
        const CustomerAddressCreateData = await schema.CustomerAddresses.create({ ...addData, userId: body?.userId, release_date: new Date() });
        res.json({ code: 200, data: CustomerAddressCreateData, message: "Create Successfully" });
    }
    else {
        addActionFunc(addAction?.id, body?.userId, body?.name);
        const CustomerAddressUpdateData = await schema.CustomerAddresses.update(addData, where);
        res.json({ code: 200, data: CustomerAddressUpdateData, message: "Update Successfully" });
    }
}
async function addActionFunc(id, custId, nameId) {
    if (id) {
        await schema.CustomerAddresses.update({ action: 0 }, { where: { id: id } });
    }
    if (nameId && custId) {
        await schema.Customers.update({ name: nameId }, { where: { id: custId } });
    }
}

this.CustomerAddresses = async (req, res) => {
    const userId = req.params.userId;
    const CustomerAddressData = await schema.CustomerAddresses.findOne({ where: { userId: userId, action: 1 } });
    res.json({ data: CustomerAddressData });
}

this.customerOrder = async (req, res) => {
    const body = req.body;
    const today = new Date();
    const hh = String(today.getHours()).padStart(2, '0');
    const mms = String(today.getMinutes()).padStart(2, '0');
    const ss = String(today.getSeconds()).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const yyyy = today.getFullYear();
    const date = dd + '-' + mm + '-' + yyyy;
    const orderId = mm * dd * yyyy + (body?.customerName.substring(0, 3).toUpperCase()) + (hh + mms + ss);
    const CustomerOrder = await schema.CustomerOrder.create({
        orderId: orderId,
        userId: body?.userId,
        customerName: body?.customerName,
        customerMobile: body?.customerMobile,
        customerCartDetails: body?.customerCartDetails,
        timeSlot: body?.timeSlot,
        addressCategory: body?.addressCategory,
        pincode: body?.pincode,
        city: body?.city,
        district: body?.district,
        state: body?.state,
        address: body?.address,
        action: body?.action,
        release_date: new Date(),
    });
    generateInvoice(CustomerOrder?.dataValues, date);
    res.json({ code: 200, data: CustomerOrder });
}

this.downloadPDF = (req, res) => {
    const invoiceName = req?.params?.invoiceName;
    res.contentType("application/pdf");
    res.download(`invoice/${invoiceName}.pdf`);
}
this.productImage = (req, res) => {
    const prodName = req?.params?.prodName;
    res.sendFile(path.join(__dirname.split(path.sep).slice(0, -1).join(path.sep), 'assets', 'productImage', prodName+'.jfif'));
}
this.sendMSG = async (req, res) => {
    const { mobile } = req?.body;
    const otp = (Math.floor(100000 + Math.random() * 900000));
    const date = new Date();
    const hrs = (date.getHours() >= 12) ? (date.getHours() - 12) : date.getHours();
    const hours = hrs < 9 ? hrs.toString().padStart(2, '0') : hrs;
    const minute = date.getMinutes() < 9 ? date.getMinutes().toString().padStart(2, '0') : date.getMinutes();
    const second = date.getSeconds() < 9 ? date.getSeconds().toString().padStart(2, '0') : date.getSeconds();
    const time = hours + ':' + minute + ':' + second;
    const shift = date.getHours() >= 12 ? 'PM' : 'AM';
    const msg = `Your breakfast OTP for login is ${otp} and is valid only for 10 minutes. # ${time + ' ' + shift}`;
    const otpMsgRes = await otpMSG(msg, mobile);
    // const otpMsgRes = '';

    const findNumber = await schema.Customers.findOne({ where: { mobile: mobile } });
    if (findNumber) {
        const updateOTP = await schema.Customers.update({ otpPwd: otp }, { where: { mobile: mobile } });
        res.json({ code: 200, data: updateOTP, msgRes: otp });
    }
    else {
        const createAcc = await schema.Customers.create({ mobile: mobile, otpPwd: otp, release_date: date });
        res.json({ code: 200, data: createAcc, msgRes: otp });
    }
}
this.verifyMsg = async (req, res) => {
    const otpVerify = req?.params?.verifyId;
    let verifyRes = await schema.Customers.findOne({ where: { otpPwd: otpVerify } });
    if (verifyRes) {
        const verifyResUpdate = await schema.Customers.update({ userId: verifyRes?.id }, { where: { id: verifyRes?.id } });
        jwt.sign(verifyRes?.dataValues, process.env.SECRET_KEY, { expiresIn: '25m' }, (err, authData) => {
            res.json({ code: 200, data: authData, message: "token generate successfully" });
        });
    }
    else {
        res.json({ code: 401, data: '', message: "Invalid otp code" });
    }
}

this.addByPin = (req, res) => {
    const pincode = req?.params?.pincode;
    addByPinCode(pincode, (address) => {
        if (address) {
            res.json({ code: 200, data: address, message: "Send Successfully" });
        }
        else {
            res.json({ code: 404, data: address, message: "Not Found Pincode" });
        }
    });
}

module.exports = this

