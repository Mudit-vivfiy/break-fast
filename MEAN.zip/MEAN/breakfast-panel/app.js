const express = require('express');
const cors = require('cors');
const app = express();
require("dotenv").config();
const { sequelize } = require('./database/db');
require("./database/schema");
require("./admin/controller");
const routes = require('./admin/routes');
app.use(
    express.urlencoded({
      extended: true,
    })
  );
app.use(express.json());
app.use(cors());
app.use('/', routes);
app.get('/home', (req, res) => {
    res.json({ name: "mudit" });
});

app.listen(3000, () => {
    console.log("Port 3000 server live.");
    sequelize.authenticate().then(() => {
        console.log('Connection has been established successfully.');
    }).catch((error) => {
        console.error('Unable to connect to the database:', error);
    });
    sequelize.sync({ alter: true }).then(() => {
        console.log('sync successfully!');
    }).catch((error) => {
        console.error('Unable to create table : ', error);
    });
});