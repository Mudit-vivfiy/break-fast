const fs = require('fs');
const { parse } = require('csv-parse');
module.exports = (picodeReq, callback) => {
    fs.createReadStream('utility/Pincode.csv').pipe(parse({ delimiter: ',' }, (err, data) => {
        var pinCode = new Array();
        var city = new Array();
        var district = new Array();
        var state = new Array();
        for (let element of data) {
            let pincode = element[4].toLowerCase();
            if (pincode == picodeReq) {
                pinCode.push(pincode);
                city.push(element[3]?.toLowerCase()?.replace(" b.o", "")?.replace(" s.o", "")?.replace(" h.o", ""));
                district.push(element[7]?.toLowerCase());
                state.push(element[8]?.toLowerCase());
            }
        };
        const datas1 = new Set(pinCode);
        const datas3 = new Set(district);
        const datas4 = new Set(state);
        const fullData = [...datas1, ...datas3, ...datas4];
        if (fullData[0]) {
            callback([...fullData, city]);
        }
        else {
            callback(...fullData);
        }
    }));
}