const fast2sms = require('fast-two-sms');
module.exports = async function (msg, mobile) {
    var options = {authorization : process.env.AUTHORIZATION , message : msg ,  numbers : [mobile], sender_id: "Breakfast"};
    const result = await fast2sms.sendMessage(options);
    return result;
}