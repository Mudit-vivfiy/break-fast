const jwt = require("jsonwebtoken");
const schema = require('../database/schema');
module.exports = async (req, res, next) => {
    const tkn = jwt.verify(req?.headers?.authentication, process.env.SECRET_KEY, { headers: true });
    if (tkn) {
        delete tkn['iat'];
        delete tkn['createdAt'];
        delete tkn['updatedAt'];
        delete tkn['exp'];
        const data = await schema.Customers.findOne({ where: tkn });
        if (data) {
            next()
        }
        else {
            res.json({ code: 401, data: '', message: 'Invalid Token' });
        }
    }
    else {
        res.json({ code: 404, data: '', message: 'Token Not Found' });
    }
}