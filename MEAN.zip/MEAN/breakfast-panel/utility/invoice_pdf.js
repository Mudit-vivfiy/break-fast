const PDFDocument = require('pdfkit');
const fs = require('fs');
// Create a document
module.exports = function (data, orderDate) {
    // Pipe its output somewhere, like to a file or HTTP response
    // See below for browser usage
    const totalPriceOff = data?.customerCartDetails?.totalPriceOff;
    const totalPrice = data?.customerCartDetails?.totalPrice;
    const CGST = (2.5 / 100) * data?.customerCartDetails?.totalPrice;
    const SGST = (2.5 / 100) * data?.customerCartDetails?.totalPrice;
    const totalDiscount = totalPriceOff - totalPrice;
    const delivery = 25;
    const packaging = 20;
    const totalsaving = delivery + packaging + CGST + SGST + totalDiscount;
    const doc = new PDFDocument({ margin: 50, size: 'A4' });
    doc.pipe(fs.createWriteStream(`invoice/${data?.orderId}.pdf`));
    doc.fontSize(20).text(data?.customerName, 30, 30, { lineBreak: false }).image("path/hot-coffee-and-good-morning.png", 420, 0, {
        fit: [100, 120],
        align: 'center',
        valign: 'center'
    });
    doc.fontSize(10);
    doc.font('fonts/OpenSans-Bold.ttf').text("Address: ", 30, 75, { lineBreak: false }).font('fonts/OpenSans-Regular.ttf').text(data?.address);
    doc.font('fonts/OpenSans-Bold.ttf').text("City: ", 30, 87, { lineBreak: false }).font('fonts/OpenSans-Regular.ttf').text(data?.city, { lineBreak: false });
    doc.font('fonts/OpenSans-Bold.ttf').text("District: ", 30, 99, { lineBreak: false }).font('fonts/OpenSans-Regular.ttf').text(data?.district, { lineBreak: false })
    doc.font('fonts/OpenSans-Bold.ttf').text("State: ", 30, 111, { lineBreak: false }).font('fonts/OpenSans-Regular.ttf').text(data?.state, { lineBreak: false });
    doc.font('fonts/OpenSans-Bold.ttf').text("Pin Code: ", 30, 123, { lineBreak: false }).font('fonts/OpenSans-Regular.ttf').text(data?.pincode, { lineBreak: true }).font('fonts/OpenSans-Bold.ttf').text("Date: ", 400, 123, { lineBreak: false }).font('fonts/OpenSans-Regular.ttf').text(orderDate);
    doc.font('fonts/OpenSans-Bold.ttf').text("Mobile No.: ", 30, 135, { lineBreak: false }).font('fonts/OpenSans-Regular.ttf').text("+91 ", { lineBreak: false }).text(data?.customerMobile, { lineBreak: true }).font('fonts/OpenSans-Bold.ttf').text("Invoice No: ", 400, 135, { lineBreak: false }).font('fonts/OpenSans-Regular.ttf').text(data?.orderId);
    doc.fontSize(12).font('fonts/OpenSans-Bold.ttf').text("Bill To:", 30, 147);
    doc.fontSize(10);
    doc.font('fonts/OpenSans-Bold.ttf').text("Customer Name: ", 30, 161, { lineBreak: false }).font('fonts/OpenSans-Regular.ttf').text(data?.customerName, { lineBreak: true });
    doc.lineCap('butt').moveTo(0, 197).lineTo(600, 197).stroke();
    doc.fontSize(10).font('fonts/OpenSans-Bold.ttf').text("Item Details", 120, 237, { width: 350, align: 'center' });
    doc.fontSize("10").font('fonts/OpenSans-Bold.ttf').text("Item Name", 50, 295).text("Qty", 175, 295).text("Unit Rate", 220, 295, { width: 90, align: 'right' }).text("Rate", 320, 295, { width: 90, align: 'right' }).text("Discount Rate", 0, 295, { align: 'right' });
    doc.lineCap('butt').moveTo(0, 287).lineTo(600, 287).stroke();
    doc.lineCap('butt').moveTo(0, 317).lineTo(600, 317).stroke();
    function generateTableRow(doc, y, c1, c2, c3, c4, c5) {
        doc.fontSize(10).font('fonts/OpenSans-Regular.ttf')
            .text(c1, 50, y)
            .text(c2, 180, y)
            .fontSize(11)
            .font('fonts/BerkaLight-9YGyn.otf')
            .text(formatCurrency(c3), 215, y, { width: 90, align: 'right' })
            .text(formatCurrency(c4), 330, y, { width: 90, align: 'right' })
            .text(formatCurrency(c5), 0, y, { align: 'right' });
    }
    function formatCurrency(paise) {
        return "₹ " + parseFloat(paise).toFixed(2);
    }
    function generateInvoiceTable(doc, invoice) {
        let i,
            invoiceTableTop = 317;
        for (i = 0; i < invoice.itemCount.length; i++) {
            const item = invoice.itemCount[i];
            const position = invoiceTableTop + (i + 1) * 30;
            // console.log(position);
            generateTableRow(doc, position, item.name, item.count, item.priceoff, item.total_priceoff, item.total_price);
        }
    }
    const Yaxis = 317 + (data?.customerCartDetails?.itemCount.length + 1) * 30;
    generateInvoiceTable(doc, data?.customerCartDetails);
    doc.lineCap('butt').moveTo(0, Yaxis + 10).lineTo(600, Yaxis + 10).stroke();
    doc.fontSize(10).font('fonts/OpenSans-Bold.ttf').text("Sub Total: ", 345, Yaxis + 20, { lineBreak: false }).fontSize(13).font('fonts/BerkaLight-9YGyn.otf').text("₹" + (totalPriceOff).toFixed(2), 500, Yaxis + 20, { align: 'right' });
    doc.fontSize(10).font('fonts/OpenSans-Bold.ttf').text("Total Discount: ", 345, Yaxis + 40, { lineBreak: false }).fontSize(13).font('fonts/BerkaLight-9YGyn.otf').text("- ₹" + (totalDiscount).toFixed(2), 500, Yaxis + 40, { align: 'right', lineBreak: false });
    doc.fontSize(10).font('fonts/OpenSans-Bold.ttf').text("CGST: ", 345, Yaxis + 60, { lineBreak: false }).fontSize(13).font('fonts/BerkaLight-9YGyn.otf').text("₹" + (CGST).toFixed(2), 500, Yaxis + 60, { align: 'right', strike: true });
    doc.fontSize(10).font('fonts/OpenSans-Bold.ttf').text("SGST: ", 345, Yaxis + 80, { lineBreak: false }).fontSize(13).font('fonts/BerkaLight-9YGyn.otf').text("₹" + (SGST).toFixed(2), 500, Yaxis + 80, { align: 'right', strike: true });
    doc.fontSize(10).font('fonts/OpenSans-Bold.ttf').text("Delivery Charge: ", 345, Yaxis + 100, { lineBreak: false }).fontSize(13).font('fonts/BerkaLight-9YGyn.otf').text("₹" + (delivery).toFixed(2), 500, Yaxis + 100, { align: 'right', strike: true });
    doc.fontSize(10).font('fonts/OpenSans-Bold.ttf').text("Packaging Charge: ", 345, Yaxis + 120, { lineBreak: false }).fontSize(13).font('fonts/BerkaLight-9YGyn.otf').text("₹" + (packaging).toFixed(2), 500, Yaxis + 120, { align: 'right', strike: true });
    doc.lineCap('butt').moveTo(320, Yaxis + 140).lineTo(600, Yaxis + 140).stroke();
    doc.fontSize(10).font('fonts/OpenSans-Bold.ttf').text("Total Saving: ", 345, Yaxis + 150, { lineBreak: false }).fontSize(13).font('fonts/BerkaLight-9YGyn.otf').text("₹" + (totalsaving).toFixed(2), 500, Yaxis + 150, { align: 'right' });
    doc.fontSize(10).font('fonts/OpenSans-Bold.ttf').text("Final Amount: ", 345, Yaxis + 170, { lineBreak: false }).fontSize(13).font('fonts/BerkaLight-9YGyn.otf').text("₹" + (totalPrice).toFixed(2), 500, Yaxis + 170, { align: 'right' });
    doc.end();
}