// var unirest = require("unirest");

// var req = unirest("GET", "https://www.fast2sms.com/dev/bulkV2");

// req.query({
//   "authorization": "vpCsUyhRc6ufSjUcvDPtKcXdpUw5tNpSIGsKAwUKQak89wfVVnKCdjiw707d",
//   "variables_values": "5599",
//   "route": "otp",
//   "numbers": "8878835145"
// });

// req.headers({
//   "cache-control": "no-cache"
// });


// req.end(function (res) {
//   if (res.error) throw new Error(res.error);

//   console.log(res.body);
// });


// var unirest = require("unirest");

// var req = unirest("POST", "https://www.fast2sms.com/dev/bulkV2");

// req.headers({
//   "authorization": "vpCsUyhRc6ufSjUcvDPtKcXdpUw5tNpSIGsKAwUKQak89wfVVnKCdjiw707d"
// });

// req.form({
//   "variables_values": "5599",
//   "route": "otp",
//   "numbers": "8878835145",
// });

// req.end(function (res) {
//   if (res.error) throw new Error(res.error);

//   console.log(res.body);
// });


var unirest = require("unirest");

var req = unirest("POST", "https://www.fast2sms.com/dev/wallet");

req.headers({
  "authorization": "vpCsUyhRc6ufSjUcvDPtKcXdpUw5tNpSIGsKAwUKQak89wfVVnKCdjiw707d"
});


req.end(function (res) {
  if (res.error) throw new Error(res.error);

  console.log(res.body);
});