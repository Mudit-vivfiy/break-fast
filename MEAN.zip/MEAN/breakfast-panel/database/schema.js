const { sequelize, DataTypes } = require('./db');

this.Food = sequelize.define("foods", {
    name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    price: {
        type: DataTypes.DECIMAL,
        allowNull: false
    },
    priceoff: {
        type: DataTypes.DECIMAL,
        allowNull: false
    },
    foodimage: {
        type: DataTypes.STRING,
        allowNull: false
    },
    description: {
        type: DataTypes.STRING,
        allowNull: false
    },
    release_date: {
        type: DataTypes.DATEONLY,
    },
    category: {
        type: DataTypes.STRING,
    }
});

this.ProductItemCount = sequelize.define("product_item_counts", {
    name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    count: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    price: {
        type: DataTypes.DECIMAL,
        allowNull: false
    },
    priceoff: {
        type: DataTypes.DECIMAL,
        allowNull: false
    },
    foodId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    foodimage: {
        type: DataTypes.STRING,
        allowNull: false
    },
    description: {
        type: DataTypes.STRING,
        allowNull: false
    },
    release_date: {
        type: DataTypes.DATEONLY,
    },
    userId: {
        type: DataTypes.INTEGER,
        allowNull: false
    }
});

this.Customers = sequelize.define("customers", {
    userId: {
        type: DataTypes.INTEGER
    },
    name: {
        type: DataTypes.STRING
    },
    mobile: {
        type: DataTypes.BIGINT,
        allowNull: false
    },
    emailId: {
        type: DataTypes.STRING
    },
    otpPwd: {
        type: DataTypes.BIGINT,
        allowNull: false
    },
    release_date: {
        type: DataTypes.DATEONLY,
    }
});


this.CustomerAddresses = sequelize.define("customer_addresses", {
    addressCategory: {
        type: DataTypes.STRING,
        allowNull: false
    },
    pincode: {
        type: DataTypes.BIGINT,
        allowNull: false
    },
    city: {
        type: DataTypes.STRING,
        allowNull: false
    },
    district: {
        type: DataTypes.STRING,
        allowNull: false
    },
    address: {
        type: DataTypes.STRING,
        allowNull: false
    },
    state: {
        type: DataTypes.STRING,
        allowNull: false
    },
    userId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    action: {
        type: DataTypes.BOOLEAN,
        allowNull: false
    },
    release_date: {
        type: DataTypes.DATEONLY,
    }
});

this.CustomerOrder = sequelize.define("customer_orders", {
    orderId: {
        type: DataTypes.STRING,
        allowNull: false
    },
    userId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    customerName: {
        type: DataTypes.STRING,
        allowNull: false
    },
    customerMobile: {
        type: DataTypes.BIGINT,
        allowNull: false
    },
    customerCartDetails: {
        type: DataTypes.JSON,
        allowNull: false
    },
    timeSlot: {
        type: DataTypes.INTEGER
    },
    addressCategory: {
        type: DataTypes.STRING,
        allowNull: false
    },
    pincode: {
        type: DataTypes.BIGINT,
        allowNull: false
    },
    city: {
        type: DataTypes.STRING,
        allowNull: false
    },
    district: {
        type: DataTypes.STRING,
        allowNull: false
    },
    state: {
        type: DataTypes.STRING,
        allowNull: false
    },
    address: {
        type: DataTypes.STRING,
        allowNull: false
    },
    action: {
        type: DataTypes.BOOLEAN,
        allowNull: false
    },
    release_date: {
        type: DataTypes.DATEONLY,
    }
});

module.exports = this